// tslint:disable-next-line:missing-jsdoc no-implicit-dependencies

/// <reference path="../build/dist/bootprompt.d.ts" />

declare const expect: Chai.ExpectStatic;
