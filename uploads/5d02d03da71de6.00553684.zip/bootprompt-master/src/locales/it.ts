/**
 * bootprompt.js locale configuration
 * locale : Italian
 * author : Mauro
 */

import { addLocale } from "../bootprompt";

addLocale("it", {
  OK: "OK",
  CANCEL: "Annulla",
  CONFIRM: "Conferma",
});
