/**
 * bootprompt.js locale configuration
 * locale : Bulgarian
 * author :  mraiur
 */

import { addLocale } from "../bootprompt";

addLocale("bg_BG", {
  OK: "Ок",
  CANCEL: "Отказ",
  CONFIRM: "Потвърждавам",
});
