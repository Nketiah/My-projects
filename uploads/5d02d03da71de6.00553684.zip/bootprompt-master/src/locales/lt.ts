/**
 * bootprompt.js locale configuration
 * locale : Lithuanian
 * author : Tomas
 */

import { addLocale } from "../bootprompt";

addLocale("lt", {
  OK: "Gerai",
  CANCEL: "Atšaukti",
  CONFIRM: "Patvirtinti",
});
