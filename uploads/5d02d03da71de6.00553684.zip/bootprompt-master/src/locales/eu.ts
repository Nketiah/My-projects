/**
 * bootprompt.js locale configuration
 * locale : Basque
 * author : Iker Ibarguren
 */

import { addLocale } from "../bootprompt";

addLocale("eu", {
  OK: "OK",
  CANCEL: "Ezeztatu",
  CONFIRM: "Onartu",
});
