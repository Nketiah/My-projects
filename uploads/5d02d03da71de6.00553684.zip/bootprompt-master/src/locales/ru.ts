/**
 * bootprompt.js locale configuration
 * locale : Russian
 * author : ionian-wind
 */

import { addLocale } from "../bootprompt";

addLocale("ru", {
  OK: "OK",
  CANCEL: "Отмена",
  CONFIRM: "Подтвердить",
});
