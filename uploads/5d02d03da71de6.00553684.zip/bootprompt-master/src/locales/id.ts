/**
 * bootprompt.js locale configuration
 * locale : Indonesian
 * author : Budi Irawan
 */

import { addLocale } from "../bootprompt";

addLocale("id", {
  OK: "OK",
  CANCEL: "Batal",
  CONFIRM: "OK",
});
