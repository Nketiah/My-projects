/**
 * bootprompt.js locale configuration
 * locale : Azerbaijani
 * author : Valentin Belousov
 */

import { addLocale } from "../bootprompt";

addLocale("az", {
  OK: "OK",
  CANCEL: "İmtina et",
  CONFIRM: "Təsdiq et",
});
