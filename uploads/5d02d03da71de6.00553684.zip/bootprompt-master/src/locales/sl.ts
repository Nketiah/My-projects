/**
 * bootprompt.js locale configuration
 * locale : Slovenian
 * author : @metalcamp
 */

import { addLocale } from "../bootprompt";

addLocale("sl", {
  OK: "OK",
  CANCEL: "Prekliči",
  CONFIRM: "Potrdi",
});
