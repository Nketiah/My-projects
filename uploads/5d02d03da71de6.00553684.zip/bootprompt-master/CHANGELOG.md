<a name="6.0.0"></a>
# [6.0.0](https://github.com/lddubeau/bootprompt/compare/v6.0.0-beta.1...v6.0.0) (2019-04-09)


### Bug Fixes

* shut up tslint ([7e7b9c2](https://github.com/lddubeau/bootprompt/commit/7e7b9c2))



