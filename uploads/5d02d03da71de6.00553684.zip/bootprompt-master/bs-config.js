module.exports = {
  server: {
    baseDir: "./build/docs",
  },
};
