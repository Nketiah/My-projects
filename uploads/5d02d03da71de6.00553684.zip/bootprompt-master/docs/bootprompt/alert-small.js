bootprompt.alert({
  message: "This is the small alert!",
  size: "small",
});
