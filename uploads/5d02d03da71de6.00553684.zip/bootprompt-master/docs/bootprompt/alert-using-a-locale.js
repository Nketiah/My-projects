bootprompt.alert({
 message: "This alert uses the Arabic locale!",
 locale: "ar",
});
