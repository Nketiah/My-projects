bootprompt.alert({
  message: "This is the large alert!",
  size: "large",
});
