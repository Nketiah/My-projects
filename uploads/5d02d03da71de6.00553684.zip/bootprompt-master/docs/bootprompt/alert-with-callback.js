bootprompt.alert("This is an alert with a callback!", () => {
  console.log("This was logged in the callback!");
});
