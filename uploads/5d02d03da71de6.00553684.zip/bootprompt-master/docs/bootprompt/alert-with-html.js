bootprompt.alert("Your message <b>here</b>");
