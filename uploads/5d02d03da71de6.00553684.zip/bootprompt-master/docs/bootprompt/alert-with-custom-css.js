bootprompt.alert({
  message: "This is an alert with additional classes!",
  className: "rubberBand animated",
});
