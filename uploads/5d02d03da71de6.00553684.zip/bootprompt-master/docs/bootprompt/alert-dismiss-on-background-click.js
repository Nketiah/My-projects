bootprompt.alert({
  message: "This alert can be dismissed by clicking on the background!",
  backdrop: true,
});
