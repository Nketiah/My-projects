bootprompt.confirm("This is the default confirm!", (result) => {
  console.log(`This was logged in the callback: ${result}`);
});
